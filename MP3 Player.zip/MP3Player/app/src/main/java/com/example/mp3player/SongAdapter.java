package com.example.mp3player;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.mp3player.databinding.ItemSongBinding;
import com.example.mp3player.models.LocalTrack;

import java.util.List;
import java.util.Locale;

public class SongAdapter extends RecyclerView.Adapter<SongAdapter.SongViewHolder> {
    private final List<LocalTrack> songList;
    private final OnSongActionListener listener;

    public interface OnSongActionListener {
        void onSongClick(LocalTrack song);
        void onEditMetadata(LocalTrack song, int position);
        void onToggleFavourite(LocalTrack song, int position);
        void onAddToPlaylist(LocalTrack song);
    }

    public SongAdapter(List<LocalTrack> songList, OnSongActionListener listener) {
        this.songList = songList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemSongBinding binding = ItemSongBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new SongViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull SongViewHolder holder, int position) {
        LocalTrack song = songList.get(position);
        holder.binding.txtSongTitleItem.setText(song.getTitle());
        holder.binding.txtArtistItem.setText(song.getArtist());
        holder.binding.txtDurationItem.setText(formatDuration((int) song.getDuration()));
        
        Glide.with(holder.itemView.getContext())
                .load(song.getCoverUrl())
                .placeholder(R.drawable.ic_music_note)
                .into(holder.binding.imgSongItem);

        holder.binding.btnFavourite.setImageResource(song.isFavourite() ? R.drawable.ic_heart_filled : R.drawable.ic_heart);
        holder.binding.btnFavourite.setOnClickListener(v -> listener.onToggleFavourite(song, position));

        holder.itemView.setOnClickListener(v -> listener.onSongClick(song));
        
        holder.binding.btnMenuSong.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(v.getContext(), v);
            popup.getMenu().add("Add to Playlist");
            popup.getMenu().add("Edit Metadata");
            popup.setOnMenuItemClickListener(item -> {
                if (item.getTitle().equals("Edit Metadata")) {
                    listener.onEditMetadata(song, position);
                } else if (item.getTitle().equals("Add to Playlist")) {
                    listener.onAddToPlaylist(song);
                }
                return true;
            });
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }

    private String formatDuration(int millis) {
        int seconds = (millis / 1000) % 60;
        int minutes = (millis / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
    }

    public static class SongViewHolder extends RecyclerView.ViewHolder {
        ItemSongBinding binding;
        public SongViewHolder(ItemSongBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}