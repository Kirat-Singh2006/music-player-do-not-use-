package com.example.mp3player.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class DeezerResponse {
    @SerializedName("data")
    public List<DeezerTrack> data;

    public static class DeezerTrack {
        @SerializedName("title")
        public String title;
        @SerializedName("artist")
        public DeezerArtist artist;
        @SerializedName("album")
        public DeezerAlbum album;
    }

    public static class DeezerArtist {
        @SerializedName("name")
        public String name;
    }

    public static class DeezerAlbum {
        @SerializedName("title")
        public String title;
        @SerializedName("cover_medium")
        public String coverMedium;
    }
}