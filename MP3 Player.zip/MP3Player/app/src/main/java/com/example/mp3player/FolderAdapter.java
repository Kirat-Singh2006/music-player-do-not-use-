package com.example.mp3player;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.RecyclerView;
import com.example.mp3player.databinding.ItemFolderBinding;
import java.util.List;

public class FolderAdapter extends RecyclerView.Adapter<FolderAdapter.FolderViewHolder> {
    private List<Uri> folderUris;
    private OnFolderRemoveListener listener;

    public interface OnFolderRemoveListener {
        void onRemove(Uri uri);
    }

    public FolderAdapter(List<Uri> folderUris, OnFolderRemoveListener listener) {
        this.folderUris = folderUris;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FolderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemFolderBinding binding = ItemFolderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new FolderViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull FolderViewHolder holder, int position) {
        Uri uri = folderUris.get(position);
        DocumentFile doc = DocumentFile.fromTreeUri(holder.itemView.getContext(), uri);
        
        holder.binding.txtFolderName.setText(doc != null ? doc.getName() : "Unknown Folder");
        holder.binding.txtFolderPath.setText(uri.toString());
        
        holder.binding.btnRemoveFolder.setOnClickListener(v -> listener.onRemove(uri));
    }

    @Override
    public int getItemCount() {
        return folderUris.size();
    }

    public static class FolderViewHolder extends RecyclerView.ViewHolder {
        ItemFolderBinding binding;
        public FolderViewHolder(ItemFolderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}