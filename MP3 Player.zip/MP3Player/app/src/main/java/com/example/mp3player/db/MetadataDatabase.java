package com.example.mp3player.db;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {MetadataEntity.class, PlaylistEntity.class, PlaylistSongEntity.class}, version = 2, exportSchema = false)
public abstract class MetadataDatabase extends RoomDatabase {
    private static MetadataDatabase instance;
    public abstract MetadataDao metadataDao();

    public static synchronized MetadataDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    MetadataDatabase.class, "metadata_db")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}