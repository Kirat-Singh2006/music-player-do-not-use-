package com.example.mp3player;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.mp3player.databinding.DialogFolderManagerBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FolderManagerBottomSheet extends BottomSheetDialogFragment {

    private DialogFolderManagerBinding binding;
    private FolderAdapter adapter;
    private List<Uri> folderUris = new ArrayList<>();
    private SharedPreferences prefs;
    private OnScanTriggeredListener scanListener;

    public interface OnScanTriggeredListener {
        void onScan(List<Uri> uris);
    }

    public static FolderManagerBottomSheet newInstance(OnScanTriggeredListener listener) {
        FolderManagerBottomSheet fragment = new FolderManagerBottomSheet();
        fragment.scanListener = listener;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DialogFolderManagerBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        prefs = requireContext().getSharedPreferences("MP3PlayerPrefs", Context.MODE_PRIVATE);
        loadSavedUris();

        adapter = new FolderAdapter(folderUris, this::removeFolder);
        binding.recyclerFolders.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerFolders.setAdapter(adapter);

        ActivityResultLauncher<Uri> folderPicker = registerForActivityResult(
                new ActivityResultContracts.OpenDocumentTree(),
                uri -> {
                    if (uri != null) {
                        requireContext().getContentResolver().takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        addFolder(uri);
                    }
                }
        );

        binding.btnAddFolder.setOnClickListener(v -> folderPicker.launch(null));
        binding.btnStartScan.setOnClickListener(v -> {
            if (scanListener != null) scanListener.onScan(folderUris);
            dismiss();
        });
    }

    private void loadSavedUris() {
        Set<String> uriStrings = prefs.getStringSet("folder_uris", new HashSet<>());
        folderUris.clear();
        for (String s : uriStrings) {
            folderUris.add(Uri.parse(s));
        }
    }

    private void saveUris() {
        Set<String> uriStrings = new HashSet<>();
        for (Uri uri : folderUris) {
            uriStrings.add(uri.toString());
        }
        prefs.edit().putStringSet("folder_uris", uriStrings).apply();
    }

    private void addFolder(Uri uri) {
        if (!folderUris.contains(uri)) {
            folderUris.add(uri);
            saveUris();
            adapter.notifyDataSetChanged();
        }
    }

    private void removeFolder(Uri uri) {
        folderUris.remove(uri);
        saveUris();
        adapter.notifyDataSetChanged();
    }
}