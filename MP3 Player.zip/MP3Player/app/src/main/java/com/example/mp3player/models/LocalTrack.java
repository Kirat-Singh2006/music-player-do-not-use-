package com.example.mp3player.models;

import java.io.Serializable;

public class LocalTrack implements Serializable {
    private long id;
    private String title;
    private String artist;
    private String album;
    private long duration;
    private String filePath;
    private String coverUrl;
    private boolean isManuallyVerified;
    private boolean isFavourite;

    public LocalTrack(long id, String title, String artist, String album, long duration, String filePath) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.duration = duration;
        this.filePath = filePath;
    }

    public long getId() { return id; }
    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public String getAlbum() { return album; }
    public long getDuration() { return duration; }
    public String getFilePath() { return filePath; }
    public String getCoverUrl() { return coverUrl; }
    public boolean isManuallyVerified() { return isManuallyVerified; }
    public boolean isFavourite() { return isFavourite; }

    public void setCoverUrl(String coverUrl) { this.coverUrl = coverUrl; }
    public void setArtist(String artist) { this.artist = artist; }
    public void setAlbum(String album) { this.album = album; }
    public void setTitle(String title) { this.title = title; }
    public void setManuallyVerified(boolean verified) { this.isManuallyVerified = verified; }
    public void setFavourite(boolean favourite) { isFavourite = favourite; }

    public String getSearchQuery() {
        if (title == null) return "";
        
        String query = title;
        
        // Remove track numbers (e.g., "01 - ", "1. ")
        query = query.replaceAll("^\\d+[\\s.-]*", "");
        
        // Remove junk strings
        String[] junk = {
            "(?i)ft\\.", "(?i)feat\\.", "(?i)remix", "(?i)live", "(?i)320kbps", 
            "(?i)official video", "(?i)lyric video", "(?i)128kbps", "(?i)lyrics",
            "(?i)high quality", "(?i)hd", "(?i)4k", "(?i)hq"
        };
        for (String j : junk) {
            query = query.replaceAll(j, "");
        }

        // Remove extensions
        query = query.replaceAll("(?i)\\.(mp3|wav|flac|m4a|aac|ogg)", "");
        
        // Remove special characters except spaces
        query = query.replaceAll("[^a-zA-Z0-9 ]", " ");
        
        if (artist != null && !artist.equalsIgnoreCase("Unknown Artist") && !artist.equals("<unknown>")) {
            query = artist + " " + query;
        }
        
        return query.replaceAll("\\s+", " ").trim();
    }
}