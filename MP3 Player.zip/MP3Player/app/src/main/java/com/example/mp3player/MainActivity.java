package com.example.mp3player;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.mp3player.databinding.ActivityMainBinding;
import com.example.mp3player.db.MetadataDao;
import com.example.mp3player.db.MetadataDatabase;
import com.example.mp3player.db.MetadataEntity;
import com.example.mp3player.db.PlaylistEntity;
import com.example.mp3player.db.PlaylistSongEntity;
import com.example.mp3player.models.LocalTrack;
import com.example.mp3player.models.PlaylistWithSongs;
import com.example.mp3player.models.iTunesResponse;
import com.example.mp3player.models.iTunesResult;
import com.example.mp3player.network.MetadataApiService;
import com.example.mp3player.utils.BackgroundMetadataScanner;
import com.example.mp3player.utils.LocalAudioScanner;
import com.example.mp3player.utils.PlaybackManager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements SongAdapter.OnSongActionListener {

    private ActivityMainBinding binding;
    private SongAdapter homeAdapter;
    private SongAdapter playlistSongAdapter;
    private PlaylistAdapter playlistAdapter;
    
    private final List<LocalTrack> homeSongList = new ArrayList<>();
    private final List<LocalTrack> playlistSongList = new ArrayList<>();
    private final List<PlaylistWithSongs> playlistItems = new ArrayList<>();
    
    private MediaPlayer mediaPlayer;
    private BackgroundMetadataScanner backgroundScanner;
    private MetadataApiService apiService;
    private MetadataDao dao;
    private PlaylistWithSongs currentVisiblePlaylist;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable updateSeekBarTask;

    private static final int STORAGE_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        dao = MetadataDatabase.getInstance(this).metadataDao();
        PlaybackManager.getInstance().init(this);
        mediaPlayer = PlaybackManager.getInstance().getMediaPlayer();
        
        setupRecyclerViews();
        setupSeekBar();

        apiService = RetrofitClient.getClient().create(MetadataApiService.class);
        backgroundScanner = new BackgroundMetadataScanner(this, apiService);

        if (checkPermission()) loadLibrary();
        else requestPermission();

        binding.btnPlayPause.setOnClickListener(v -> togglePlayback());
        binding.miniPlayer.setOnClickListener(v -> {
            LocalTrack currentTrack = PlaybackManager.getInstance().getCurrentTrack();
            if (currentTrack != null) {
                Intent intent = new Intent(this, NowPlayingActivity.class);
                intent.putExtra("TRACK", currentTrack);
                startActivity(intent);
            }
        });

        binding.btnCreatePlaylist.setOnClickListener(v -> showCreatePlaylistDialog());
        binding.btnAddSongsToPlaylist.setOnClickListener(v -> showAddSongsToPlaylistDialog());

        setupBottomNav();
        ensureFavouritesPlaylist();
    }

    private void ensureFavouritesPlaylist() {
        new Thread(() -> {
            PlaylistEntity fav = dao.getPlaylistByName("Favourites");
            if (fav == null) {
                dao.insertPlaylist(new PlaylistEntity("Favourites"));
            }
        }).start();
    }

    private void setupBottomNav() {
        binding.bottomNavLayout.navHome.setOnClickListener(v -> {
            currentVisiblePlaylist = null;
            updateBottomNavUI(true);
        });

        binding.bottomNavLayout.navLibrary.setOnClickListener(v -> {
            currentVisiblePlaylist = null;
            updateBottomNavUI(false);
            loadPlaylists();
        });
        
        updateBottomNavUI(true);
    }

    private void updateBottomNavUI(boolean isHome) {
        int activeColor = Color.parseColor("#6200EE");
        int inactiveColor = Color.parseColor("#88333333");

        binding.bottomNavLayout.imgHome.setColorFilter(isHome ? activeColor : inactiveColor);
        binding.bottomNavLayout.txtHome.setTextColor(isHome ? activeColor : inactiveColor);

        binding.bottomNavLayout.imgLibrary.setColorFilter(!isHome ? activeColor : inactiveColor);
        binding.bottomNavLayout.txtLibrary.setTextColor(!isHome ? activeColor : inactiveColor);
        
        if (isHome) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.libraryContainer.setVisibility(View.GONE);
            binding.toolbar.setTitle("Local MP3 Player");
        } else {
            binding.recyclerView.setVisibility(View.GONE);
            binding.libraryContainer.setVisibility(View.VISIBLE);
            if (currentVisiblePlaylist == null) {
                binding.playlistOverview.setVisibility(View.VISIBLE);
                binding.playlistDetails.setVisibility(View.GONE);
                binding.toolbar.setTitle("Library");
            } else {
                binding.playlistOverview.setVisibility(View.GONE);
                binding.playlistDetails.setVisibility(View.VISIBLE);
                binding.toolbar.setTitle(currentVisiblePlaylist.playlist.name);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalTrack track = PlaybackManager.getInstance().getCurrentTrack();
        if (track != null) {
            updatePlayerUI(track);
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                binding.seekBar.setMax(mediaPlayer.getDuration());
                binding.txtTotalDuration.setText(formatTime(mediaPlayer.getDuration()));
                handler.post(updateSeekBarTask);
            }
        }
    }

    private void setupRecyclerViews() {
        homeAdapter = new SongAdapter(homeSongList, this);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(homeAdapter);

        playlistAdapter = new PlaylistAdapter(playlistItems, this::showPlaylistSongs);
        binding.recyclerPlaylists.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerPlaylists.setAdapter(playlistAdapter);

        playlistSongAdapter = new SongAdapter(playlistSongList, this);
        binding.recyclerPlaylistSongs.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerPlaylistSongs.setAdapter(playlistSongAdapter);
    }

    private void showPlaylistSongs(PlaylistWithSongs playlist) {
        currentVisiblePlaylist = playlist;
        playlistSongList.clear();
        playlistSongList.addAll(playlist.songs);
        playlistSongAdapter.notifyDataSetChanged();
        
        new Thread(() -> {
            PlaylistEntity favPlaylist = dao.getPlaylistByName("Favourites");
            if (favPlaylist != null) {
                for (LocalTrack track : playlistSongList) {
                    boolean isFav = dao.isSongInPlaylist(favPlaylist.id, track.getFilePath()) > 0;
                    track.setFavourite(isFav);
                }
                runOnUiThread(() -> playlistSongAdapter.notifyDataSetChanged());
            }
        }).start();

        updateBottomNavUI(false);
    }

    private void showAddSongsToPlaylistDialog() {
        if (currentVisiblePlaylist == null) return;

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_songs, null);
        final ProgressBar progressBar = dialogView.findViewById(R.id.progressLoading);
        final RecyclerView recyclerView = dialogView.findViewById(R.id.recyclerAddSongs);
        
        final List<LocalTrack> allSongs = new ArrayList<>();
        final SongSelectionAdapter selectionAdapter = new SongSelectionAdapter(allSongs, currentVisiblePlaylist.songs);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(selectionAdapter);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Select Songs")
                .setView(dialogView)
                .setPositiveButton("Add", (d, which) -> {
                    Set<String> selected = selectionAdapter.getSelectedPaths();
                    new Thread(() -> {
                        for (LocalTrack s : allSongs) {
                            if (selected.contains(s.getFilePath())) {
                                dao.addSongToPlaylist(new PlaylistSongEntity(currentVisiblePlaylist.playlist.id, s.getFilePath()));
                                if (dao.getMetadata(s.getFilePath()) == null) {
                                    dao.insertMetadata(new MetadataEntity(s.getFilePath(), s.getTitle(), s.getArtist(), s.getAlbum(), s.getCoverUrl(), false));
                                }
                            }
                        }
                        runOnUiThread(() -> {
                            loadPlaylists();
                            new Thread(() -> {
                                List<MetadataEntity> songMetas = dao.getEnrichedSongsForPlaylist(currentVisiblePlaylist.playlist.id);
                                List<LocalTrack> tracks = new ArrayList<>();
                                for (MetadataEntity m : songMetas) {
                                    LocalTrack t = new LocalTrack(0, m.matchedTitle, m.matchedArtist, m.matchedAlbum, 0, m.filePath);
                                    t.setCoverUrl(m.coverUrl);
                                    tracks.add(t);
                                }
                                runOnUiThread(() -> {
                                    currentVisiblePlaylist.songs = tracks;
                                    showPlaylistSongs(currentVisiblePlaylist);
                                });
                            }).start();
                        });
                    }).start();
                })
                .setNegativeButton("Cancel", null)
                .create();

        dialog.show();

        new Thread(() -> {
            Set<String> uriStrings = getSharedPreferences("MP3PlayerPrefs", Context.MODE_PRIVATE)
                    .getStringSet("folder_uris", new HashSet<>());
            List<Uri> uris = new ArrayList<>();
            for (String s : uriStrings) uris.add(Uri.parse(s));
            
            LocalAudioScanner.scanSelectedFolders(this, uris, track -> {
                MetadataEntity meta = dao.getMetadata(track.getFilePath());
                if (meta != null) {
                    track.setCoverUrl(meta.coverUrl);
                    track.setArtist(meta.matchedArtist);
                    track.setTitle(meta.matchedTitle);
                }
                runOnUiThread(() -> {
                    allSongs.add(track);
                    selectionAdapter.notifyItemInserted(allSongs.size() - 1);
                    if (progressBar.getVisibility() == View.VISIBLE) {
                        progressBar.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                    }
                });
            });
        }).start();
    }

    private void setupSeekBar() {
        binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mediaPlayer != null) {
                    mediaPlayer.seekTo(progress);
                    binding.txtElapsedTime.setText(formatTime(progress));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { handler.removeCallbacks(updateSeekBarTask); }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { if (mediaPlayer != null && mediaPlayer.isPlaying()) handler.post(updateSeekBarTask); }
        });

        updateSeekBarTask = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    int currentPos = mediaPlayer.getCurrentPosition();
                    binding.seekBar.setProgress(currentPos);
                    binding.txtElapsedTime.setText(formatTime(currentPos));
                    handler.postDelayed(this, 200);
                }
            }
        };
    }

    private void loadLibrary() {
        Set<String> uriStrings = getSharedPreferences("MP3PlayerPrefs", Context.MODE_PRIVATE)
                .getStringSet("folder_uris", new HashSet<>());
        List<Uri> uris = new ArrayList<>();
        for (String s : uriStrings) uris.add(Uri.parse(s));

        if (uris.isEmpty()) {
            Toast.makeText(this, "Add folders in Library -> Menu to begin.", Toast.LENGTH_LONG).show();
            return;
        }

        homeSongList.clear();
        homeAdapter.notifyDataSetChanged();

        new Thread(() -> {
            LocalAudioScanner.scanSelectedFolders(this, uris, track -> {
                MetadataEntity meta = dao.getMetadata(track.getFilePath());
                if (meta != null) {
                    track.setCoverUrl(meta.coverUrl);
                    PlaylistEntity favPlaylist = dao.getPlaylistByName("Favourites");
                    if (favPlaylist != null) {
                        boolean isFav = dao.isSongInPlaylist(favPlaylist.id, track.getFilePath()) > 0;
                        track.setFavourite(isFav);
                    }
                }

                runOnUiThread(() -> {
                    homeSongList.add(track);
                    homeAdapter.notifyItemInserted(homeSongList.size() - 1);
                    
                    backgroundScanner.submit(track, enriched -> {
                        int idx = homeSongList.indexOf(enriched);
                        if (idx != -1) {
                            homeAdapter.notifyItemChanged(idx);
                        }
                    });
                });
            });
        }).start();
    }

    private void loadPlaylists() {
        new Thread(() -> {
            List<PlaylistEntity> entities = dao.getAllPlaylists();
            List<PlaylistWithSongs> items = new ArrayList<>();
            for (PlaylistEntity entity : entities) {
                List<MetadataEntity> songMetas = dao.getEnrichedSongsForPlaylist(entity.id);
                List<LocalTrack> tracks = new ArrayList<>();
                for (MetadataEntity m : songMetas) {
                    LocalTrack t = new LocalTrack(0, m.matchedTitle, m.matchedArtist, m.matchedAlbum, 0, m.filePath);
                    t.setCoverUrl(m.coverUrl);
                    tracks.add(t);
                }
                items.add(new PlaylistWithSongs(entity, tracks));
            }
            runOnUiThread(() -> {
                playlistItems.clear();
                playlistItems.addAll(items);
                playlistAdapter.notifyDataSetChanged();
            });
        }).start();
    }

    @Override
    public void onSongClick(LocalTrack song) {
        List<LocalTrack> currentList = currentVisiblePlaylist != null ? playlistSongList : homeSongList;
        int index = currentList.indexOf(song);
        PlaybackManager.getInstance().setPlaylist(currentList, index);
        updatePlayerUI(song);
        if (mediaPlayer != null) {
            binding.seekBar.setMax(mediaPlayer.getDuration());
            binding.txtTotalDuration.setText(formatTime(mediaPlayer.getDuration()));
        }
        handler.post(updateSeekBarTask);
    }

    @Override
    public void onAddToPlaylist(LocalTrack song) {
        new Thread(() -> {
            List<PlaylistEntity> allPlaylists = dao.getAllPlaylists();
            runOnUiThread(() -> {
                String[] names = new String[allPlaylists.size()];
                for (int i = 0; i < allPlaylists.size(); i++) names[i] = allPlaylists.get(i).name;

                new AlertDialog.Builder(this)
                        .setTitle("Add to Playlist")
                        .setItems(names, (dialog, which) -> {
                            PlaylistEntity selected = allPlaylists.get(which);
                            new Thread(() -> {
                                dao.addSongToPlaylist(new PlaylistSongEntity(selected.id, song.getFilePath()));
                                if (dao.getMetadata(song.getFilePath()) == null) {
                                    dao.insertMetadata(new MetadataEntity(song.getFilePath(), song.getTitle(), song.getArtist(), song.getAlbum(), song.getCoverUrl(), false));
                                }
                                runOnUiThread(() -> {
                                    Toast.makeText(this, "Added to " + selected.name, Toast.LENGTH_SHORT).show();
                                    loadPlaylists();
                                });
                            }).start();
                        })
                        .show();
            });
        }).start();
    }

    @Override
    public void onToggleFavourite(LocalTrack song, int position) {
        new Thread(() -> {
            PlaylistEntity favPlaylist = dao.getPlaylistByName("Favourites");
            if (favPlaylist != null) {
                if (song.isFavourite()) {
                    dao.removeSongFromPlaylist(favPlaylist.id, song.getFilePath());
                    song.setFavourite(false);
                } else {
                    dao.addSongToPlaylist(new PlaylistSongEntity(favPlaylist.id, song.getFilePath()));
                    song.setFavourite(true);
                    if (dao.getMetadata(song.getFilePath()) == null) {
                        dao.insertMetadata(new MetadataEntity(song.getFilePath(), song.getTitle(), song.getArtist(), song.getAlbum(), song.getCoverUrl(), false));
                    }
                }
                runOnUiThread(() -> {
                    homeAdapter.notifyDataSetChanged();
                    playlistSongAdapter.notifyDataSetChanged();
                    
                    if (currentVisiblePlaylist != null && currentVisiblePlaylist.playlist.name.equals("Favourites")) {
                        if (!song.isFavourite()) {
                            playlistSongList.remove(position);
                            playlistSongAdapter.notifyItemRemoved(position);
                        }
                    }
                });
            }
        }).start();
    }

    private void updatePlayerUI(LocalTrack track) {
        binding.txtSongTitle.setText(track.getTitle());
        binding.txtArtist.setText(track.getArtist());
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            binding.btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
        } else {
            binding.btnPlayPause.setImageResource(android.R.drawable.ic_media_play);
        }
        Glide.with(this).load(track.getCoverUrl()).placeholder(R.drawable.ic_music_note).into(binding.imgAlbumArt);
    }

    @Override
    public void onEditMetadata(LocalTrack song, int position) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_metadata, null);
        EditText editTitle = dialogView.findViewById(R.id.editTitle);
        EditText editArtist = dialogView.findViewById(R.id.editArtist);
        RecyclerView recyclerCovers = dialogView.findViewById(R.id.recyclerCovers);
        
        editTitle.setText(song.getTitle());
        editArtist.setText(song.getArtist());

        final String[] selectedCover = {song.getCoverUrl()};
        CoverAdapter coverAdapter = new CoverAdapter(url -> selectedCover[0] = url);
        recyclerCovers.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerCovers.setAdapter(coverAdapter);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        dialogView.findViewById(R.id.btnSearchCovers).setOnClickListener(v -> {
            String q = editArtist.getText().toString() + " " + editTitle.getText().toString();
            apiService.searchiTunes(q, "music", 5).enqueue(new Callback<iTunesResponse>() {
                @Override
                public void onResponse(@NonNull Call<iTunesResponse> call, @NonNull Response<iTunesResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        List<String> urls = new ArrayList<>();
                        for (iTunesResult r : response.body().getResults()) urls.add(r.getHighResArtworkUrl());
                        runOnUiThread(() -> coverAdapter.setCovers(urls));
                    }
                }
                @Override public void onFailure(@NonNull Call<iTunesResponse> call, @NonNull Throwable t) {}
            });
        });

        dialogView.findViewById(R.id.btnSaveMetadata).setOnClickListener(v -> {
            song.setTitle(editTitle.getText().toString());
            song.setArtist(editArtist.getText().toString());
            song.setCoverUrl(selectedCover[0]);
            song.setManuallyVerified(true);
            backgroundScanner.updateManual(song);
            
            homeAdapter.notifyDataSetChanged();
            playlistSongAdapter.notifyDataSetChanged();
            
            if (binding.txtSongTitle.getText().toString().equals(song.getTitle())) updatePlayerUI(song);
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showCreatePlaylistDialog() {
        EditText input = new EditText(this);
        new AlertDialog.Builder(this)
                .setTitle("New Playlist")
                .setMessage("Enter playlist name")
                .setView(input)
                .setPositiveButton("Create", (dialog, which) -> {
                    String name = input.getText().toString();
                    if (!name.isEmpty()) {
                        new Thread(() -> {
                            dao.insertPlaylist(new PlaylistEntity(name));
                            loadPlaylists();
                        }).start();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void togglePlayback() {
        PlaybackManager.getInstance().togglePlayback();
        LocalTrack track = PlaybackManager.getInstance().getCurrentTrack();
        if (track != null) updatePlayerUI(track);
    }

    private String formatTime(int millis) {
        int sec = (millis / 1000) % 60;
        int min = (millis / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%d:%02d", min, sec);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_refresh) {
            FolderManagerBottomSheet.newInstance(uris -> loadLibrary()).show(getSupportFragmentManager(), "Folders");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean checkPermission() {
        String p = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        String p = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        ActivityCompat.requestPermissions(this, new String[]{p}, STORAGE_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadLibrary();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateSeekBarTask);
        if (backgroundScanner != null) backgroundScanner.shutdown();
    }
}