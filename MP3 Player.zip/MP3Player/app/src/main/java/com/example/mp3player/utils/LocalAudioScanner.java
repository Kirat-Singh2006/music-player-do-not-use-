package com.example.mp3player.utils;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import com.example.mp3player.models.LocalTrack;
import java.util.List;

public class LocalAudioScanner {

    public interface OnTrackDiscoveredListener {
        void onTrackDiscovered(LocalTrack track);
    }

    public static void scanSelectedFolders(Context context, List<Uri> folderUris, OnTrackDiscoveredListener listener) {
        for (Uri uri : folderUris) {
            DocumentFile root = DocumentFile.fromTreeUri(context, uri);
            if (root != null && root.isDirectory()) {
                scanRecursive(context, root, listener);
            }
        }
    }

    private static void scanRecursive(Context context, DocumentFile dir, OnTrackDiscoveredListener listener) {
        DocumentFile[] files = dir.listFiles();
        if (files == null) return;

        for (DocumentFile file : files) {
            if (file.isDirectory()) {
                scanRecursive(context, file, listener);
            } else {
                String name = file.getName();
                if (name != null && (name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".wav") || name.endsWith(".flac"))) {
                    
                    String title = name.replaceAll("(?i)\\.(mp3|m4a|wav|flac)", "");
                    String artist = "Unknown Artist";
                    String album = "Local Folder";
                    long duration = 0;

                    // Extract ID3 tags
                    try (MediaMetadataRetriever retriever = new MediaMetadataRetriever()) {
                        retriever.setDataSource(context, file.getUri());
                        String embeddedTitle = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                        String embeddedArtist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                        String embeddedAlbum = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                        String durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);

                        if (embeddedTitle != null && !embeddedTitle.isEmpty()) title = embeddedTitle;
                        if (embeddedArtist != null && !embeddedArtist.isEmpty()) artist = embeddedArtist;
                        if (embeddedAlbum != null && !embeddedAlbum.isEmpty()) album = embeddedAlbum;
                        if (durStr != null) duration = Long.parseLong(durStr);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    
                    LocalTrack track = new LocalTrack(
                            System.currentTimeMillis() + (int)(Math.random() * 1000), 
                            title, 
                            artist, 
                            album, 
                            duration, 
                            file.getUri().toString()
                    );
                    
                    if (listener != null) {
                        listener.onTrackDiscovered(track);
                    }
                }
            }
        }
    }
}