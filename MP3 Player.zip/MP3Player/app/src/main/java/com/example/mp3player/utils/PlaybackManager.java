package com.example.mp3player.utils;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;

import com.example.mp3player.models.LocalTrack;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PlaybackManager {
    private static PlaybackManager instance;
    private MediaPlayer mediaPlayer;
    private LocalTrack currentTrack;
    private List<LocalTrack> playlist = new ArrayList<>();
    private List<LocalTrack> originalPlaylist = new ArrayList<>();
    private int currentIndex = -1;
    private boolean isShuffle = false;
    private boolean isRepeat = false;
    private OnPlaybackListener listener;
    private Context appContext;

    public interface OnPlaybackListener {
        void onTrackChanged(LocalTrack track);
        void onPlaybackStatusChanged(boolean isPlaying);
    }

    private PlaybackManager() {
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(mp -> playNext());
    }

    public static synchronized PlaybackManager getInstance() {
        if (instance == null) {
            instance = new PlaybackManager();
        }
        return instance;
    }

    public void init(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public void setListener(OnPlaybackListener listener) {
        this.listener = listener;
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public LocalTrack getCurrentTrack() {
        return currentTrack;
    }

    public void setPlaylist(List<LocalTrack> tracks, int startIndex) {
        this.originalPlaylist = new ArrayList<>(tracks);
        this.playlist = new ArrayList<>(tracks);
        if (isShuffle) {
            shufflePlaylist(startIndex);
        } else {
            this.currentIndex = startIndex;
        }
        play(playlist.get(currentIndex));
    }

    private void shufflePlaylist(int currentTrackIndex) {
        LocalTrack current = playlist.get(currentTrackIndex);
        playlist.remove(currentTrackIndex);
        Collections.shuffle(playlist);
        playlist.add(0, current);
        currentIndex = 0;
    }

    public List<LocalTrack> getPlaylist() {
        return playlist;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public void playAtIndex(int index) {
        if (index >= 0 && index < playlist.size()) {
            currentIndex = index;
            play(playlist.get(currentIndex));
        }
    }

    public void play(LocalTrack track) {
        if (currentTrack != null && currentTrack.getFilePath().equals(track.getFilePath())) {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start();
                if (listener != null) listener.onPlaybackStatusChanged(true);
            }
            return;
        }

        currentTrack = track;
        try {
            mediaPlayer.reset();
            if (appContext != null) {
                mediaPlayer.setDataSource(appContext, Uri.parse(track.getFilePath()));
            } else {
                mediaPlayer.setDataSource(track.getFilePath());
            }
            mediaPlayer.prepare();
            mediaPlayer.start();
            if (listener != null) {
                listener.onTrackChanged(track);
                listener.onPlaybackStatusChanged(true);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void togglePlayback() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        } else {
            mediaPlayer.start();
        }
        if (listener != null) listener.onPlaybackStatusChanged(mediaPlayer.isPlaying());
    }

    public void playNext() {
        if (isRepeat) {
            play(currentTrack);
            return;
        }
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        play(playlist.get(currentIndex));
    }

    public void playPrevious() {
        if (playlist.isEmpty()) return;
        currentIndex--;
        if (currentIndex < 0) currentIndex = playlist.size() - 1;
        play(playlist.get(currentIndex));
    }

    public boolean isPlaying() {
        return mediaPlayer.isPlaying();
    }

    public boolean isShuffle() {
        return isShuffle;
    }

    public void setShuffle(boolean shuffle) {
        isShuffle = shuffle;
        if (isShuffle && !playlist.isEmpty()) {
            shufflePlaylist(currentIndex);
        } else if (!isShuffle) {
            LocalTrack current = currentTrack;
            playlist = new ArrayList<>(originalPlaylist);
            currentIndex = playlist.indexOf(current);
        }
    }

    public boolean isRepeat() {
        return isRepeat;
    }

    public void setRepeat(boolean repeat) {
        isRepeat = repeat;
    }
}