package com.example.mp3player;

import android.media.audiofx.Equalizer;
import android.media.audiofx.Visualizer;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mp3player.databinding.ActivityEqualizerBinding;

import java.util.ArrayList;
import java.util.List;

public class EqualizerActivity extends AppCompatActivity {
    private ActivityEqualizerBinding binding;
    private Equalizer equalizer;
    private Visualizer visualizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEqualizerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int sessionId = getIntent().getIntExtra("AUDIO_SESSION_ID", -1);
        if (sessionId != -1) {
            setupEqualizer(sessionId);
            setupVisualizer(sessionId);
        }
    }

    private void setupEqualizer(int sessionId) {
        equalizer = new Equalizer(0, sessionId);
        equalizer.setEnabled(true);

        short bands = equalizer.getNumberOfBands();
        final short minLevel = equalizer.getBandLevelRange()[0];
        final short maxLevel = equalizer.getBandLevelRange()[1];

        for (short i = 0; i < bands; i++) {
            final short band = i;
            TextView freqText = new TextView(this);
            freqText.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            freqText.setText((equalizer.getCenterFreq(band) / 1000) + " Hz");
            binding.equalizerContainer.addView(freqText);

            SeekBar seekBar = new SeekBar(this);
            seekBar.setMax(maxLevel - minLevel);
            seekBar.setProgress(equalizer.getBandLevel(band) - minLevel);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    equalizer.setBandLevel(band, (short) (progress + minLevel));
                }
                @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                @Override public void onStopTrackingTouch(SeekBar seekBar) {}
            });
            binding.equalizerContainer.addView(seekBar);
        }

        setupPresets();
    }

    private void setupPresets() {
        List<String> presets = new ArrayList<>();
        for (short i = 0; i < equalizer.getNumberOfPresets(); i++) {
            presets.add(equalizer.getPresetName(i));
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, presets);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.presetSpinner.setAdapter(adapter);
    }

    private void setupVisualizer(int sessionId) {
        visualizer = new Visualizer(sessionId);
        visualizer.setCaptureSize(Visualizer.getCaptureSizeRange()[1]);
        visualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
            @Override
            public void onWaveFormDataCapture(Visualizer visualizer, byte[] waveform, int samplingRate) {
                binding.visualizerView.updateVisualizer(waveform);
            }
            @Override public void onFftDataCapture(Visualizer visualizer, byte[] fft, int samplingRate) {}
        }, Visualizer.getMaxCaptureRate() / 2, true, false);
        visualizer.setEnabled(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (equalizer != null) equalizer.release();
        if (visualizer != null) visualizer.release();
    }
}