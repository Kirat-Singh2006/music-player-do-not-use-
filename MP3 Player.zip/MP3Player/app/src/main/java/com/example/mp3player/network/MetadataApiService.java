package com.example.mp3player.network;

import com.example.mp3player.models.iTunesResponse;
import com.example.mp3player.models.DeezerResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface MetadataApiService {
    @GET("search")
    Call<iTunesResponse> searchiTunes(
            @Query("term") String term,
            @Query("media") String media,
            @Query("limit") int limit
    );

    @GET
    Call<DeezerResponse> searchDeezer(
            @Url String url,
            @Query("q") String query
    );
}