package com.example.mp3player;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CoverAdapter extends RecyclerView.Adapter<CoverAdapter.CoverViewHolder> {
    private List<String> coverUrls = new ArrayList<>();
    private final OnCoverSelectedListener listener;

    public interface OnCoverSelectedListener {
        void onCoverSelected(String url);
    }

    public CoverAdapter(OnCoverSelectedListener listener) {
        this.listener = listener;
    }

    public void setCovers(List<String> urls) {
        this.coverUrls = urls;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CoverViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cover_candidate, parent, false);
        return new CoverViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CoverViewHolder holder, int position) {
        String url = coverUrls.get(position);
        Glide.with(holder.itemView.getContext())
                .load(url)
                .placeholder(R.drawable.ic_music_note)
                .into(holder.imgCover);
        
        holder.itemView.setOnClickListener(v -> listener.onCoverSelected(url));
    }

    @Override
    public int getItemCount() {
        return coverUrls.size();
    }

    public static class CoverViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCover;
        public CoverViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = (ImageView) itemView;
        }
    }
}