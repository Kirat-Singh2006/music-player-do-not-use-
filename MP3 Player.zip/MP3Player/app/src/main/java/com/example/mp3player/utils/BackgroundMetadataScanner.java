package com.example.mp3player.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.example.mp3player.db.MetadataDao;
import com.example.mp3player.db.MetadataDatabase;
import com.example.mp3player.db.MetadataEntity;
import com.example.mp3player.models.DeezerResponse;
import com.example.mp3player.models.LocalTrack;
import com.example.mp3player.models.iTunesResponse;
import com.example.mp3player.models.iTunesResult;
import com.example.mp3player.network.MetadataApiService;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Response;

public class BackgroundMetadataScanner {

    private final MetadataApiService apiService;
    private final MetadataDao metadataDao;
    private final ExecutorService executorService;
    private final Handler mainHandler;
    private static final String TAG = "MetadataScanner";

    public interface OnMetadataEnrichedListener {
        void onEnriched(LocalTrack track);
    }

    public BackgroundMetadataScanner(Context context, MetadataApiService apiService) {
        this.apiService = apiService;
        this.metadataDao = MetadataDatabase.getInstance(context).metadataDao();
        this.executorService = Executors.newFixedThreadPool(4);
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public void submit(LocalTrack track, OnMetadataEnrichedListener listener) {
        executorService.execute(() -> {
            // 1. Check Cache
            MetadataEntity cached = metadataDao.getMetadata(track.getFilePath());
            if (cached != null) {
                track.setTitle(cached.matchedTitle);
                track.setArtist(cached.matchedArtist);
                track.setAlbum(cached.matchedAlbum);
                track.setCoverUrl(cached.coverUrl);
                track.setManuallyVerified(cached.isManuallyVerified);
                mainHandler.post(() -> listener.onEnriched(track));
                return;
            }

            // 2. Query Chain
            if (tryiTunes(track) || tryDeezer(track)) {
                // Save to Cache
                metadataDao.insertMetadata(new MetadataEntity(
                        track.getFilePath(), track.getTitle(), track.getArtist(), 
                        track.getAlbum(), track.getCoverUrl(), false));
                
                mainHandler.post(() -> listener.onEnriched(track));
            }
        });
    }

    private boolean tryiTunes(LocalTrack track) {
        try {
            Response<iTunesResponse> response = apiService.searchiTunes(track.getSearchQuery(), "music", 1).execute();
            if (response.isSuccessful() && response.body() != null && response.body().getResultCount() > 0) {
                iTunesResult result = response.body().getResults().get(0);
                track.setCoverUrl(result.getHighResArtworkUrl());
                track.setArtist(result.getArtistName());
                track.setAlbum(result.getCollectionName());
                return true;
            }
        } catch (IOException e) {
            Log.e(TAG, "iTunes failed", e);
        }
        return false;
    }

    private boolean tryDeezer(LocalTrack track) {
        try {
            Response<DeezerResponse> response = apiService.searchDeezer("https://api.deezer.com/search", track.getSearchQuery()).execute();
            if (response.isSuccessful() && response.body() != null && response.body().data != null && !response.body().data.isEmpty()) {
                DeezerResponse.DeezerTrack result = response.body().data.get(0);
                track.setCoverUrl(result.album.coverMedium);
                track.setArtist(result.artist.name);
                track.setAlbum(result.album.title);
                return true;
            }
        } catch (IOException e) {
            Log.e(TAG, "Deezer failed", e);
        }
        return false;
    }

    public void updateManual(LocalTrack track) {
        executorService.execute(() -> {
            metadataDao.insertMetadata(new MetadataEntity(
                    track.getFilePath(), track.getTitle(), track.getArtist(),
                    track.getAlbum(), track.getCoverUrl(), true));
        });
    }

    public void shutdown() {
        executorService.shutdown();
    }
}