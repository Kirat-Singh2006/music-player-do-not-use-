package com.example.mp3player;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.mp3player.databinding.ItemSongSelectableBinding;
import com.example.mp3player.models.LocalTrack;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class SongSelectionAdapter extends RecyclerView.Adapter<SongSelectionAdapter.ViewHolder> {
    private final List<LocalTrack> songList;
    private final Set<String> selectedPaths = new HashSet<>();

    public SongSelectionAdapter(List<LocalTrack> songList, List<LocalTrack> initialSelection) {
        this.songList = songList;
        if (initialSelection != null) {
            for (LocalTrack t : initialSelection) {
                selectedPaths.add(t.getFilePath());
            }
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemSongSelectableBinding binding = ItemSongSelectableBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LocalTrack song = songList.get(position);
        holder.binding.txtSongTitleItem.setText(song.getTitle());
        holder.binding.txtArtistItem.setText(song.getArtist());
        holder.binding.txtDurationItem.setText(formatDuration((int) song.getDuration()));
        
        Glide.with(holder.itemView.getContext())
                .load(song.getCoverUrl())
                .placeholder(R.drawable.ic_music_note)
                .into(holder.binding.imgSongItem);

        boolean isSelected = selectedPaths.contains(song.getFilePath());
        holder.binding.checkBox.setChecked(isSelected);
        
        holder.binding.checkBox.setOnClickListener(v -> toggleSelection(song, position));
        holder.itemView.setOnClickListener(v -> toggleSelection(song, position));
    }

    private void toggleSelection(LocalTrack song, int position) {
        if (selectedPaths.contains(song.getFilePath())) {
            selectedPaths.remove(song.getFilePath());
        } else {
            selectedPaths.add(song.getFilePath());
        }
        notifyItemChanged(position);
    }

    public Set<String> getSelectedPaths() {
        return selectedPaths;
    }

    @Override
    public int getItemCount() {
        return songList.size();
    }

    private String formatDuration(int millis) {
        int seconds = (millis / 1000) % 60;
        int minutes = (millis / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%d:%02d", minutes, seconds);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ItemSongSelectableBinding binding;
        public ViewHolder(ItemSongSelectableBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}