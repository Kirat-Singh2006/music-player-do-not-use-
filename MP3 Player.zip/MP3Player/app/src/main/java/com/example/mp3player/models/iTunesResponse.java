package com.example.mp3player.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class iTunesResponse {
    @SerializedName("resultCount")
    private int resultCount;

    @SerializedName("results")
    private List<iTunesResult> results;

    public int getResultCount() { return resultCount; }
    public List<iTunesResult> getResults() { return results; }
}