package com.example.mp3player;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mp3player.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding binding;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sharedPreferences = getSharedPreferences("MP3PlayerPrefs", MODE_PRIVATE);
        String savedUri = sharedPreferences.getString("MUSIC_FOLDER_URI", null);
        if (savedUri != null) {
            binding.txtSelectedFolder.setText(savedUri);
        }

        ActivityResultLauncher<Uri> folderPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocumentTree(),
                uri -> {
                    if (uri != null) {
                        getContentResolver().takePersistableUriPermission(uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        sharedPreferences.edit().putString("MUSIC_FOLDER_URI", uri.toString()).apply();
                        binding.txtSelectedFolder.setText(uri.toString());
                    }
                }
        );

        binding.btnSelectFolder.setOnClickListener(v -> folderPickerLauncher.launch(null));
    }
}