package com.example.mp3player;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mp3player.databinding.ItemPlaylistBinding;
import com.example.mp3player.models.LocalTrack;
import com.example.mp3player.models.PlaylistWithSongs;
import com.example.mp3player.utils.CollageUtils;

import java.util.ArrayList;
import java.util.List;

public class PlaylistAdapter extends RecyclerView.Adapter<PlaylistAdapter.PlaylistViewHolder> {
    private final List<PlaylistWithSongs> playlists;
    private final OnPlaylistActionListener listener;

    public interface OnPlaylistActionListener {
        void onPlaylistClick(PlaylistWithSongs playlist);
    }

    public PlaylistAdapter(List<PlaylistWithSongs> playlists, OnPlaylistActionListener listener) {
        this.playlists = playlists;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PlaylistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPlaylistBinding binding = ItemPlaylistBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new PlaylistViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PlaylistViewHolder holder, int position) {
        PlaylistWithSongs item = playlists.get(position);
        if (item == null || item.playlist == null) return;
        
        holder.binding.txtPlaylistName.setText(item.playlist.name);
        holder.binding.txtSongCount.setText(String.format("%d songs", item.songs != null ? item.songs.size() : 0));

        List<String> covers = new ArrayList<>();
        if (item.songs != null) {
            for (int i = 0; i < Math.min(item.songs.size(), 4); i++) {
                covers.add(item.songs.get(i).getCoverUrl());
            }
        }

        CollageUtils.createCollage(holder.itemView.getContext(), covers, 200, bitmap -> {
            if (bitmap != null) {
                holder.binding.imgPlaylistCover.setImageBitmap(bitmap);
            } else {
                holder.binding.imgPlaylistCover.setImageResource(R.drawable.ic_music_note);
            }
        });

        holder.itemView.setOnClickListener(v -> listener.onPlaylistClick(item));
    }

    @Override
    public int getItemCount() {
        return playlists.size();
    }

    public static class PlaylistViewHolder extends RecyclerView.ViewHolder {
        ItemPlaylistBinding binding;
        public PlaylistViewHolder(ItemPlaylistBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}