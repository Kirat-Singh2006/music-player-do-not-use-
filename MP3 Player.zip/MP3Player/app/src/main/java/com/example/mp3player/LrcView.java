package com.example.mp3player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class LrcView extends View {
    private TreeMap<Long, String> lrcData = new TreeMap<>();
    private Paint paint = new Paint();
    private long currentTime = 0;

    public LrcView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        paint.setTextSize(40f);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setAntiAlias(true);
    }

    public void setLrcData(TreeMap<Long, String> data) {
        this.lrcData = data;
        invalidate();
    }

    public void updateTime(long time) {
        this.currentTime = time;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (lrcData.isEmpty()) return;

        Long floorKey = lrcData.floorKey(currentTime);
        if (floorKey != null) {
            String currentLyric = lrcData.get(floorKey);
            canvas.drawText(currentLyric, getWidth() / 2f, getHeight() / 2f, paint);
        }
    }
}