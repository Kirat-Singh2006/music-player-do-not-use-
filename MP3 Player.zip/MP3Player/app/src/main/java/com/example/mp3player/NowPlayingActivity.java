package com.example.mp3player;

import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.example.mp3player.databinding.ActivityNowPlayingBinding;
import com.example.mp3player.models.LocalTrack;
import com.example.mp3player.utils.PlaybackManager;

import java.util.List;
import java.util.Locale;

public class NowPlayingActivity extends AppCompatActivity {

    private ActivityNowPlayingBinding binding;
    private LocalTrack currentTrack;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable updateProgressTask;
    private AudioManager audioManager;
    private boolean isUserSwiping = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNowPlayingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        currentTrack = (LocalTrack) getIntent().getSerializableExtra("TRACK");
        if (currentTrack == null) {
            finish();
            return;
        }

        mediaPlayer = PlaybackManager.getInstance().getMediaPlayer();
        
        setupAlbumArtPager();
        populateUI();
        setupPlayback();
        setupVolumeControl();
        setupControls();
        setupBottomNav();

        binding.btnBack.setOnClickListener(v -> finish());
        binding.btnPlayPauseContainer.setOnClickListener(v -> PlaybackManager.getInstance().togglePlayback());
    }

    private void setupAlbumArtPager() {
        List<LocalTrack> playlist = PlaybackManager.getInstance().getPlaylist();
        AlbumArtAdapter adapter = new AlbumArtAdapter(playlist);
        binding.albumArtPager.setAdapter(adapter);
        
        int currentIndex = PlaybackManager.getInstance().getCurrentIndex();
        binding.albumArtPager.setCurrentItem(currentIndex, false);

        binding.albumArtPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
                isUserSwiping = (state == ViewPager2.SCROLL_STATE_DRAGGING || state == ViewPager2.SCROLL_STATE_SETTLING);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                if (isUserSwiping) {
                    PlaybackManager.getInstance().playAtIndex(position);
                }
            }
        });
    }

    private void populateUI() {
        binding.txtNowPlayingTitle.setText(currentTrack.getTitle());
        binding.txtNowPlayingArtist.setText(currentTrack.getArtist());

        if (!isUserSwiping) {
            int index = PlaybackManager.getInstance().getCurrentIndex();
            if (binding.albumArtPager.getCurrentItem() != index) {
                binding.albumArtPager.setCurrentItem(index, true);
            }
        }

        if (mediaPlayer != null) {
            binding.waveformSeekBar.setMax(mediaPlayer.getDuration());
            binding.txtTotalTimeNP.setText(formatTime(mediaPlayer.getDuration()));
        }
    }

    private void setupPlayback() {
        LocalTrack playingTrack = PlaybackManager.getInstance().getCurrentTrack();
        if (playingTrack == null || !playingTrack.getFilePath().equals(currentTrack.getFilePath())) {
            PlaybackManager.getInstance().play(currentTrack);
        }

        binding.waveformSeekBar.setMax(mediaPlayer.getDuration());
        binding.txtTotalTimeNP.setText(formatTime(mediaPlayer.getDuration()));

        binding.waveformSeekBar.setOnSeekBarChangeListener((seekBar, progress, fromUser) -> {
            if (fromUser && mediaPlayer != null) {
                mediaPlayer.seekTo(progress);
                binding.txtCurrentTimeNP.setText(formatTime(progress));
            }
        });

        updateProgressTask = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    int pos = mediaPlayer.getCurrentPosition();
                    binding.waveformSeekBar.setProgress(pos);
                    binding.txtCurrentTimeNP.setText(formatTime(pos));
                    handler.postDelayed(this, 200);
                }
            }
        };
        handler.post(updateProgressTask);

        PlaybackManager.getInstance().setListener(new PlaybackManager.OnPlaybackListener() {
            @Override
            public void onTrackChanged(LocalTrack track) {
                currentTrack = track;
                runOnUiThread(() -> populateUI());
            }

            @Override
            public void onPlaybackStatusChanged(boolean isPlaying) {
                runOnUiThread(() -> {
                    if (isPlaying) {
                        binding.btnPlayPauseNP.setImageResource(android.R.drawable.ic_media_pause);
                        handler.post(updateProgressTask);
                    } else {
                        binding.btnPlayPauseNP.setImageResource(R.drawable.ic_play);
                        handler.removeCallbacks(updateProgressTask);
                    }
                });
            }
        });

        if (mediaPlayer.isPlaying()) {
            binding.btnPlayPauseNP.setImageResource(android.R.drawable.ic_media_pause);
        } else {
            binding.btnPlayPauseNP.setImageResource(R.drawable.ic_play);
        }
    }

    private void setupControls() {
        binding.btnShuffle.setOnClickListener(v -> {
            PlaybackManager.getInstance().setShuffle(!PlaybackManager.getInstance().isShuffle());
            updateShuffleRepeatUI();
        });

        binding.btnRepeat.setOnClickListener(v -> {
            PlaybackManager.getInstance().setRepeat(!PlaybackManager.getInstance().isRepeat());
            updateShuffleRepeatUI();
        });

        binding.btnPrevNP.setOnClickListener(v -> PlaybackManager.getInstance().playPrevious());
        binding.btnNextNP.setOnClickListener(v -> PlaybackManager.getInstance().playNext());

        updateShuffleRepeatUI();
    }

    private void updateShuffleRepeatUI() {
        int activeColor = Color.parseColor("#6200EE");
        int inactiveColor = Color.parseColor("#333333");
        binding.btnShuffle.setColorFilter(PlaybackManager.getInstance().isShuffle() ? activeColor : inactiveColor);
        binding.btnRepeat.setColorFilter(PlaybackManager.getInstance().isRepeat() ? activeColor : inactiveColor);
    }

    private void setupBottomNav() {
        binding.bottomNavLayout.navHome.setOnClickListener(v -> finish());
        binding.bottomNavLayout.navLibrary.setOnClickListener(v -> updateBottomNavUI(false));
        updateBottomNavUI(false);
    }

    private void updateBottomNavUI(boolean isHome) {
        int activeColor = Color.parseColor("#333333");
        int inactiveColor = Color.parseColor("#88333333");
        binding.bottomNavLayout.imgHome.setColorFilter(isHome ? activeColor : inactiveColor);
        binding.bottomNavLayout.txtHome.setTextColor(isHome ? activeColor : inactiveColor);
        binding.bottomNavLayout.imgLibrary.setColorFilter(!isHome ? activeColor : inactiveColor);
        binding.bottomNavLayout.txtLibrary.setTextColor(!isHome ? activeColor : inactiveColor);
    }

    private void setupVolumeControl() {
        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        binding.volumeSlider.setValueFrom(0);
        binding.volumeSlider.setValueTo(maxVol);
        binding.volumeSlider.setValue(curVol);
        binding.volumeSlider.addOnChangeListener((slider, value, fromUser) -> 
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (int) value, 0));
    }

    private String formatTime(int millis) {
        int sec = (millis / 1000) % 60;
        int min = (millis / (1000 * 60)) % 60;
        return String.format(Locale.getDefault(), "%d:%02d", min, sec);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateProgressTask);
        PlaybackManager.getInstance().setListener(null);
    }
}