package com.example.mp3player.models;

import com.google.gson.annotations.SerializedName;

public class iTunesResult {
    @SerializedName("artistName")
    private String artistName;

    @SerializedName("collectionName")
    private String collectionName;

    @SerializedName("trackName")
    private String trackName;

    @SerializedName("artworkUrl100")
    private String artworkUrl100;

    public String getArtistName() { return artistName; }
    public String getCollectionName() { return collectionName; }
    public String getTrackName() { return trackName; }
    public String getArtworkUrl100() { return artworkUrl100; }

    /**
     * Converts the default 100x100 artwork to 600x600 for better quality.
     */
    public String getHighResArtworkUrl() {
        if (artworkUrl100 == null) return null;
        return artworkUrl100.replace("100x100bb", "600x600bb");
    }
}