package com.example.mp3player.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;

@Entity(tableName = "playlist_songs", primaryKeys = {"playlistId", "songFilePath"})
public class PlaylistSongEntity {
    public int playlistId;
    @NonNull
    public String songFilePath;

    public PlaylistSongEntity(int playlistId, @NonNull String songFilePath) {
        this.playlistId = playlistId;
        this.songFilePath = songFilePath;
    }
}