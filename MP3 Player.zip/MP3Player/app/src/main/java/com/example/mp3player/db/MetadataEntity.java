package com.example.mp3player.db;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "metadata_cache")
public class MetadataEntity {
    @PrimaryKey
    @NonNull
    public String filePath;
    public String matchedTitle;
    public String matchedArtist;
    public String matchedAlbum;
    public String coverUrl;
    public boolean isManuallyVerified;

    public MetadataEntity(@NonNull String filePath, String matchedTitle, String matchedArtist, String matchedAlbum, String coverUrl, boolean isManuallyVerified) {
        this.filePath = filePath;
        this.matchedTitle = matchedTitle;
        this.matchedArtist = matchedArtist;
        this.matchedAlbum = matchedAlbum;
        this.coverUrl = coverUrl;
        this.isManuallyVerified = isManuallyVerified;
    }
}