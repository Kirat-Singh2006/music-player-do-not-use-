package com.example.mp3player.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.Random;

public class WaveformSeekBar extends View {

    private Paint inactivePaint = new Paint();
    private Paint activePaint = new Paint();
    private float[] samples;
    private int max = 100;
    private int progress = 0;
    private OnSeekBarChangeListener listener;

    public interface OnSeekBarChangeListener {
        void onProgressChanged(WaveformSeekBar seekBar, int progress, boolean fromUser);
    }

    public WaveformSeekBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        inactivePaint.setColor(Color.LTGRAY);
        inactivePaint.setStrokeWidth(4f);
        inactivePaint.setAntiAlias(true);

        activePaint.setColor(Color.parseColor("#4A47E0"));
        activePaint.setStrokeWidth(4f);
        activePaint.setAntiAlias(true);

        generateMockWaveform();
    }

    private void generateMockWaveform() {
        Random random = new Random();
        samples = new float[50];
        for (int i = 0; i < samples.length; i++) {
            samples[i] = random.nextFloat();
        }
    }

    public void setMax(int max) {
        this.max = max;
        invalidate();
    }

    public void setProgress(int progress) {
        this.progress = progress;
        invalidate();
    }

    public void setOnSeekBarChangeListener(OnSeekBarChangeListener listener) {
        this.listener = listener;
    }

    public void setActiveColor(int color) {
        activePaint.setColor(color);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (samples == null) return;

        float width = getWidth();
        float height = getHeight();
        float spacing = width / samples.length;
        float progressX = (float) progress / max * width;

        for (int i = 0; i < samples.length; i++) {
            float x = i * spacing + (spacing / 2);
            float barHeight = samples[i] * height;
            float startY = (height - barHeight) / 2;
            float stopY = startY + barHeight;

            Paint paint = (x <= progressX) ? activePaint : inactivePaint;
            canvas.drawLine(x, startY, x, stopY, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
            float x = event.getX();
            int newProgress = (int) (x / getWidth() * max);
            newProgress = Math.max(0, Math.min(max, newProgress));
            if (listener != null) {
                listener.onProgressChanged(this, newProgress, true);
            }
            setProgress(newProgress);
            return true;
        }
        return super.onTouchEvent(event);
    }
}