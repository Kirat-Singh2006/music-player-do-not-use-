package com.example.mp3player.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "playlists")
public class PlaylistEntity {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;

    public PlaylistEntity(String name) {
        this.name = name;
    }
}