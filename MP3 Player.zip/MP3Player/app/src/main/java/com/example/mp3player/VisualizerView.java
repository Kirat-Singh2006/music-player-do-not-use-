package com.example.mp3player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class VisualizerView extends View {
    private byte[] bytes;
    private Paint paint = new Paint();

    public VisualizerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        paint.setStrokeWidth(8f);
        paint.setAntiAlias(true);
        paint.setColor(Color.BLUE);
    }

    public void updateVisualizer(byte[] bytes) {
        this.bytes = bytes;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bytes == null) return;

        float width = getWidth();
        float height = getHeight();
        float barWidth = width / bytes.length;

        for (int i = 0; i < bytes.length; i++) {
            float x = i * barWidth;
            float y = height - (Math.abs(bytes[i]) * (height / 128));
            canvas.drawLine(x, height, x, y, paint);
        }
    }
}