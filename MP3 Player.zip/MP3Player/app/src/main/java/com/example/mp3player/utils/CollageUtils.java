package com.example.mp3player.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.mp3player.R;

import java.util.List;

public class CollageUtils {

    public interface CollageCallback {
        void onCollageReady(Bitmap bitmap);
    }

    public static void createCollage(Context context, List<String> urls, int size, CollageCallback callback) {
        if (urls == null || urls.isEmpty()) {
            callback.onCollageReady(null);
            return;
        }

        final Context appContext = context.getApplicationContext();

        if (urls.size() < 4) {
            Glide.with(appContext)
                    .asBitmap()
                    .load(urls.get(0))
                    .placeholder(R.drawable.ic_music_note)
                    .error(R.drawable.ic_music_note)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            callback.onCollageReady(resource);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {}

                        @Override
                        public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            callback.onCollageReady(null);
                        }
                    });
            return;
        }

        final Bitmap collage = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(collage);
        final int halfSize = size / 2;
        final int[] count = {0};

        for (int i = 0; i < 4; i++) {
            final int index = i;
            String url = urls.get(i);
            
            Glide.with(appContext)
                    .asBitmap()
                    .load(url)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            drawToQuadrant(resource, index, halfSize, size, canvas);
                            checkComplete();
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {}

                        @Override
                        public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            Drawable d = ContextCompat.getDrawable(appContext, R.drawable.ic_music_note);
                            if (d != null) {
                                Bitmap b = Bitmap.createBitmap(halfSize, halfSize, Bitmap.Config.ARGB_8888);
                                Canvas c = new Canvas(b);
                                d.setBounds(0, 0, halfSize, halfSize);
                                d.draw(c);
                                drawToQuadrant(b, index, halfSize, size, canvas);
                            }
                            checkComplete();
                        }

                        private void checkComplete() {
                            count[0]++;
                            if (count[0] == 4) {
                                callback.onCollageReady(collage);
                            }
                        }
                    });
        }
    }

    private static void drawToQuadrant(Bitmap bitmap, int index, int halfSize, int size, Canvas canvas) {
        if (bitmap == null) return;
        Rect src = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        Rect dst;
        if (index == 0) dst = new Rect(0, 0, halfSize, halfSize);
        else if (index == 1) dst = new Rect(halfSize, 0, size, halfSize);
        else if (index == 2) dst = new Rect(0, halfSize, halfSize, size);
        else dst = new Rect(halfSize, halfSize, size, size);
        canvas.drawBitmap(bitmap, src, dst, null);
    }
}