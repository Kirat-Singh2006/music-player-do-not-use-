package com.example.mp3player.models;

import com.example.mp3player.db.PlaylistEntity;
import java.util.List;

public class PlaylistWithSongs {
    public PlaylistEntity playlist;
    public List<LocalTrack> songs;

    public PlaylistWithSongs(PlaylistEntity playlist, List<LocalTrack> songs) {
        this.playlist = playlist;
        this.songs = songs;
    }
}