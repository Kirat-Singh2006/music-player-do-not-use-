package com.example.mp3player;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LrcParser {
    public static TreeMap<Long, String> parse(InputStream is) {
        TreeMap<Long, String> lrcData = new TreeMap<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            String line;
            Pattern pattern = Pattern.compile("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\](.*)");
            while ((line = reader.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    long min = Long.parseLong(matcher.group(1));
                    long sec = Long.parseLong(matcher.group(2));
                    long mil = Long.parseLong(matcher.group(3));
                    if (matcher.group(3).length() == 2) mil *= 10;
                    long time = min * 60 * 1000 + sec * 1000 + mil;
                    String text = matcher.group(4);
                    lrcData.put(time, text);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lrcData;
    }
}