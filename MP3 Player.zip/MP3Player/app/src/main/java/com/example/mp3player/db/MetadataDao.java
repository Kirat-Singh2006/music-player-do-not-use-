package com.example.mp3player.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MetadataDao {
    @Query("SELECT * FROM metadata_cache WHERE filePath = :path LIMIT 1")
    MetadataEntity getMetadata(String path);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMetadata(MetadataEntity entity);

    // Playlist methods
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insertPlaylist(PlaylistEntity playlist);

    @Query("SELECT * FROM playlists")
    List<PlaylistEntity> getAllPlaylists();

    @Query("SELECT * FROM playlists WHERE name = :name LIMIT 1")
    PlaylistEntity getPlaylistByName(String name);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addSongToPlaylist(PlaylistSongEntity playlistSong);

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songFilePath = :songFilePath")
    void removeSongFromPlaylist(int playlistId, String songFilePath);

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId")
    List<PlaylistSongEntity> getSongsForPlaylist(int playlistId);

    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlistId = :playlistId AND songFilePath = :songFilePath")
    int isSongInPlaylist(int playlistId, String songFilePath);

    @Query("SELECT * FROM metadata_cache WHERE filePath IN (SELECT songFilePath FROM playlist_songs WHERE playlistId = :playlistId)")
    List<MetadataEntity> getEnrichedSongsForPlaylist(int playlistId);
}